#include <Arduino.h>
#include "sensor_read.h"
#include "control_logic.h"
#include "web_config.h"
#include "display.h"
#include "buttons.h"
#include "fan_sensor.h"
#include "variables.h"

// WiFi for testing
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// Globals
bool manual_override = false;

float internal_temp = 0, internal_hum = 0, ambient_temp = 0, ambient_hum = 0;
float upper_temp_threshold = 35, lower_temp_threshold = 25;
float upper_hum_threshold = 75, lower_hum_threshold = 45;
int mode = 1;
String priority = "Temperature";
int timer_value = 10;
bool timer_active = false;
bool switch_manual = false;
bool relay_state = false;
int fan_speed = 0;
int current_menu = 1;
bool edit_mode = false;

unsigned long lastLog = 0;

void setup() {
  Serial.begin(115200);
  delay(200);
  initSensors();
  initControl();
  initDisplay();
  initButtons();
  initFanSensor();
  startWebServer(ssid, password);
  showRealtimeData();
  Serial.println("[BOOT] System started. Connect to / web UI.");
}

void loop() {
  readSensors();
  updateFanSpeed();
  handleButtons();
  updateControl();
  updateDisplayIfNeeded();

  // Debug logs every 2s
  if (millis() - lastLog >= 2000) {
    lastLog = millis();
    Serial.printf("[DATA] Ambient: %.1fC / %.0f%% | Internal: %.1fC / %.0f%%\n",
                  ambient_temp, ambient_hum, internal_temp, internal_hum);
    Serial.printf("[MODE] %s | Relay: %s | Fan: %d RPM | Priority: %s | Tmr: %s (%d min)\n",
                  mode==1?"Auto":mode==2?"Manual":"Timer",
                  relay_state?"ON":"OFF", fan_speed, priority.c_str(),
                  timer_active?"ACTIVE":"IDLE", timer_value);
  }

  delay(100);
}
