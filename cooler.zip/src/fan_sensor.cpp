#include "fan_sensor.h"
#include "variables.h"

#define FAN_PIN 12  // Tachometer input, 1 pulse per revolution

volatile unsigned long pulseCount = 0;
unsigned long lastCalc = 0;

void IRAM_ATTR onPulse() {
  pulseCount++;
}

void initFanSensor() {
  pinMode(FAN_PIN, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(FAN_PIN), onPulse, FALLING);
  Serial.println("[INIT] Fan sensor initialized (1 pulse/rev).");
}

void updateFanSpeed() {
  unsigned long now = millis();
  if (now - lastCalc >= 1000) {
    noInterrupts();
    unsigned long cnt = pulseCount;
    pulseCount = 0;
    interrupts();
    fan_speed = (int)(cnt * 60); // RPM
    lastCalc = now;
  }
}
