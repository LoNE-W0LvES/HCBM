#include "control_logic.h"
#include "variables.h"

#define RELAY_PIN 11

unsigned long coolerTimerStart = 0;
static bool timerState = false;
static bool lastSwitchState = false;

void initControl() {
  pinMode(RELAY_PIN, OUTPUT);
  digitalWrite(RELAY_PIN, LOW);
  relay_state = false;
  Serial.println("[INIT] Cooler control initialized.");
}

void updateControl() {
  bool relay_on = relay_state;

  // ===================================================
  // 🔘 Detect physical button press (rising edge)
  // ===================================================
  if (switch_manual && !lastSwitchState) {
    manual_override = true;               // mark manual event
    relay_state = !relay_state;           // flip state immediately
    digitalWrite(RELAY_PIN, relay_state ? HIGH : LOW);
    Serial.printf("[BUTTON] Relay toggled manually -> %s\n", relay_state ? "ON" : "OFF");

    // Timer mode: also flip timer phase and reset countdown

    // timerState = relay_state;
    // coolerTimerStart = millis();


    lastSwitchState = switch_manual;      // update button state
    return;                               // ⚠️ Skip the rest of control logic this cycle
  }
  lastSwitchState = switch_manual;

  // ===================================================
  // 🧠 Mode-specific control logic
  // ===================================================

  // AUTO MODE — sensors + temporary manual override
  if (mode == 1) {
    if (manual_override) {
      // hold manual toggle until environment crosses back
      relay_on = relay_state;

      bool stableLow  = (internal_temp <= lower_temp_threshold && internal_hum <= lower_hum_threshold);
      bool stableHigh = (internal_temp > upper_temp_threshold  || internal_hum > upper_hum_threshold);

      if (stableLow || stableHigh) {
        manual_override = false;
        Serial.println("[AUTO] Manual override cleared — auto resumed.");
      }
    } else {
      // normal auto control
      if (priority == "Temperature") {
        relay_on = (internal_temp > upper_temp_threshold);
      } else if (priority == "Humidity") {
        relay_on = (internal_hum > upper_hum_threshold);
      } else { // Both
        relay_on = (internal_temp > upper_temp_threshold) || (internal_hum > upper_hum_threshold);
      }
    }
  }

  // MANUAL MODE — web or physical button
  else if (mode == 2) {
    relay_on = relay_state;
  }

  // TIMER MODE — automatic with manual flip capability
  else if (mode == 3) {
    unsigned long elapsedMin = (millis() - coolerTimerStart) / 60000UL;

    // flip automatically when time reached
    if (elapsedMin >= (unsigned long)timer_value) {
      coolerTimerStart = millis();
      timerState = !timerState;
      Serial.printf("[TIMER] Auto flip -> %s\n", timerState ? "ON" : "OFF");
    }

    // web manual flip (from dashboard)
    if (manual_override) {
      timerState = !timerState;
      coolerTimerStart = millis();
      manual_override = false;
      Serial.printf("[TIMER] Manual flip (web/button) -> %s\n", timerState ? "ON" : "OFF");
    }

    relay_on = timerState;
  }

  // ===================================================
  // ⚡ Apply Relay Output
  // ===================================================
  if (relay_on != relay_state) {
    relay_state = relay_on;
    digitalWrite(RELAY_PIN, relay_state ? HIGH : LOW);
    Serial.printf("[COOLER] Relay %s\n", relay_state ? "ON" : "OFF");
  }
}
