#include "web_config.h"
#include "variables.h"
#include <WiFi.h>
#include <ESPAsyncWebServer.h>
#include <AsyncTCP.h>
#include <ArduinoJson.h>

AsyncWebServer server(80);

// ================================================
// HTML PAGE
// ================================================
const char MAIN_page[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Smart Cooler Dashboard</title>
<style>
  body {font-family: Arial; background: #f5f7fa; text-align:center; margin:0; padding:20px;}
  .card {
    background:#fff; padding:20px; margin:10px auto; border-radius:10px;
    box-shadow:0 2px 5px rgba(0,0,0,0.2); max-width:420px;
  }
  h2 {margin-top:0;}
  p {margin:5px 0;}
  input, select {
    padding:4px; border-radius:4px; border:1px solid #ccc; text-align:center;
  }
  button {
    padding:8px 20px; border:none; border-radius:6px; color:#fff;
    background:#2196F3; cursor:pointer; margin:4px;
  }
  button.off {background:#777;}
  .save {background:#4CAF50;}
</style>
</head>
<body>

<div class="card">
  <h2>Smart Cooler</h2>
  <p>পরিবেশের তাপমাত্রা: <span id="ambT">--</span> °C</p>
  <p>Internal Temperature: <span id="intT">--</span> °C</p>
  <p>Ambient Humidity: <span id="ambH">--</span> %</p>
  <p>Internal Humidity: <span id="intH">--</span> %</p>
  <p>Fan Speed: <span id="fan">--</span> RPM</p>
  <hr>
  <p>
    Mode:
    <select id="modeSel" onchange="setMode()">
      <option value="1">Auto</option>
      <option value="2">Manual</option>
      <option value="3">Timer</option>
    </select>
  </p>
  <p>
    Priority:
    <select id="prioSel" onchange="updatePriority()">
      <option value="Temperature">Temperature</option>
      <option value="Humidity">Humidity</option>
      <option value="None">Both</option>
    </select>
  </p>
  <button id="relayBtn" class="off" onclick="toggleRelay()">Relay OFF</button>
  <div id="timerBox" style="display:none;">
    <p>Timer: <span id="timerVal">--</span> min</p>
    <p>Elapsed: <span id="elapsed">00:00:00</span></p>
  </div>
</div>

<div class="card">
  <h3>Configuration</h3>
  <form id="configForm">
    <p>Upper Temp (°C): <input type="number" step="0.5" id="upperT"></p>
    <p>Lower Temp (°C): <input type="number" step="0.5" id="lowerT"></p>
    <p>Upper Hum (%): <input type="number" step="1" id="upperH"></p>
    <p>Lower Hum (%): <input type="number" step="1" id="lowerH"></p>
    <p>Timer (minutes): <input type="number" step="1" id="timerCfg"></p>
    <button type="submit" class="save">💾 Save</button>
  </form>
</div>

<script>
let currentMode = 1;
let relayState = false;
let timerValue = 0;
let elapsedSec = 0;

// Fetch Live Data
async function fetchData() {
  const res = await fetch('/data');
  const d = await res.json();

  document.getElementById('ambT').textContent = d.ambient_temp_rt.toFixed(1);
  document.getElementById('intT').textContent = d.temp_rt.toFixed(1);
  document.getElementById('ambH').textContent = d.ambient_hum_rt.toFixed(0);
  document.getElementById('intH').textContent = d.hum_rt.toFixed(0);
  document.getElementById('fan').textContent = d.fan_speed;

  currentMode = d.mode;
  relayState = d.relay_state;
  timerValue = d.timer_value;
  elapsedSec = d.timer_elapsed;

  document.getElementById('modeSel').value = currentMode;
  document.getElementById('prioSel').value = d.priority;

  // Only update fields if user isn't editing
  if (document.activeElement.id !== 'upperT') document.getElementById('upperT').value = d.upper_temp_threshold;
  if (document.activeElement.id !== 'lowerT') document.getElementById('lowerT').value = d.lower_temp_threshold;
  if (document.activeElement.id !== 'upperH') document.getElementById('upperH').value = d.upper_hum_threshold;
  if (document.activeElement.id !== 'lowerH') document.getElementById('lowerH').value = d.lower_hum_threshold;
  if (document.activeElement.id !== 'timerCfg') document.getElementById('timerCfg').value = d.timer_value;

  const relayBtn = document.getElementById('relayBtn');
  relayBtn.textContent = relayState ? "Relay ON" : "Relay OFF";
  relayBtn.className = relayState ? "" : "off";

  const timerBox = document.getElementById('timerBox');
  if (currentMode == 3) {
    timerBox.style.display = "block";
    document.getElementById('timerVal').textContent = timerValue;
    const hh = String(Math.floor(elapsedSec / 3600)).padStart(2, '0');
    const mm = String(Math.floor((elapsedSec % 3600) / 60)).padStart(2, '0');
    const ss = String(elapsedSec % 60).padStart(2, '0');
    document.getElementById('elapsed').textContent = `${hh}:${mm}:${ss}`;
  } else timerBox.style.display = "none";
}

// Relay Toggle
async function toggleRelay() {
  relayState = !relayState;
  await fetch(`/relay?state=${relayState ? 1 : 0}`);
  fetchData();
}

// Mode / Priority
async function setMode() {
  currentMode = parseInt(document.getElementById('modeSel').value);
  await fetch(`/mode?set=${currentMode}`);
  fetchData();
}
async function updatePriority() {
  const pr = document.getElementById('prioSel').value;
  await fetch(`/priority?set=${pr}`);
  fetchData();
}

// Save Config
document.getElementById('configForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const cfg = {
    upper_temp_threshold: parseFloat(upperT.value),
    lower_temp_threshold: parseFloat(lowerT.value),
    upper_hum_threshold: parseFloat(upperH.value),
    lower_hum_threshold: parseFloat(lowerH.value),
    priority: prioSel.value,
    mode: parseInt(modeSel.value),
    timer_value: parseInt(timerCfg.value)
  };
  await fetch('/save', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify(cfg)
  });
  alert("Configuration Saved!");
});

// Loop
setInterval(fetchData, 1000);
fetchData();
</script>
</body>
</html>
)rawliteral";

// ================================================
// SERVER LOGIC
// ================================================
void startWebServer(const char* ssid, const char* password){
  WiFi.begin(ssid,password);
  Serial.println("[WIFI] Connecting...");
  while(WiFi.status()!=WL_CONNECTED){ delay(400); Serial.print("."); }
  Serial.println("\n[WIFI] Connected! IP: " + WiFi.localIP().toString());

  server.on("/", HTTP_GET, [](AsyncWebServerRequest *req){
    req->send_P(200, "text/html", MAIN_page);
  });

  // Live data
  server.on("/data", HTTP_GET, [](AsyncWebServerRequest *request){
    JsonDocument doc;
    doc["ambient_temp_rt"] = ambient_temp;
    doc["ambient_hum_rt"]  = ambient_hum;
    doc["temp_rt"]         = internal_temp;
    doc["hum_rt"]          = internal_hum;
    doc["fan_speed"]       = fan_speed;
    doc["relay_state"]     = relay_state;
    doc["mode"]            = mode;
    doc["priority"]        = priority;
    doc["timer_value"]     = timer_value;
    doc["upper_temp_threshold"] = upper_temp_threshold;
    doc["lower_temp_threshold"] = lower_temp_threshold;
    doc["upper_hum_threshold"]  = upper_hum_threshold;
    doc["lower_hum_threshold"]  = lower_hum_threshold;
    doc["timer_elapsed"]   = (millis()/1000UL) % (timer_value*60UL);
    String out; serializeJson(doc,out);
    request->send(200,"application/json",out);
  });

  // Relay toggle
  server.on("/relay", HTTP_GET, [](AsyncWebServerRequest *request){
    if(request->hasParam("state")){
      String state = request->getParam("state")->value();
      relay_state = (state == "1");
      manual_override = true;
      digitalWrite(11, relay_state ? HIGH : LOW);
      Serial.printf("[WEB] Relay manually set -> %s\n", relay_state ? "ON" : "OFF");
    }
    request->send(200,"text/plain","OK");
  });

  // Mode change
  server.on("/mode", HTTP_GET, [](AsyncWebServerRequest *request){
    if(request->hasParam("set")){
      mode = request->getParam("set")->value().toInt();
      manual_override = false;
      Serial.printf("[WEB] Mode -> %d\n", mode);
    }
    request->send(200,"text/plain","Mode Updated");
  });

  // Priority
  server.on("/priority", HTTP_GET, [](AsyncWebServerRequest *request){
    if(request->hasParam("set")){
      priority = request->getParam("set")->value();
      Serial.printf("[WEB] Priority -> %s\n", priority.c_str());
    }
    request->send(200,"text/plain","Priority Updated");
  });

  // Save config
  server.on("/save", HTTP_POST, [](AsyncWebServerRequest *request){}, NULL,
  [](AsyncWebServerRequest *request, uint8_t *data, size_t len, size_t index, size_t total){
    JsonDocument doc;
    if(deserializeJson(doc,data)) {request->send(400,"text/plain","Invalid JSON"); return;}
    upper_temp_threshold = doc["upper_temp_threshold"];
    lower_temp_threshold = doc["lower_temp_threshold"];
    upper_hum_threshold  = doc["upper_hum_threshold"];
    lower_hum_threshold  = doc["lower_hum_threshold"];
    priority             = String((const char*)doc["priority"]);
    mode                 = doc["mode"];
    timer_value          = doc["timer_value"];
    Serial.println("[WEB] Config saved.");
    request->send(200,"text/plain","Saved");
  });

  server.begin();
  Serial.println("[HTTP] Web server started.");
}
