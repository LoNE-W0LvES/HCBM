#ifndef VARIABLES_H
#define VARIABLES_H

#include <Arduino.h>

// Real-time readings
extern float internal_temp, internal_hum;
extern float ambient_temp, ambient_hum;

// Thresholds
extern float upper_temp_threshold;
extern float lower_temp_threshold;
extern float upper_hum_threshold;
extern float lower_hum_threshold;

// Config
extern int mode;              // 1=Auto, 2=Manual, 3=Timer
extern String priority;       // "Temperature" or "Humidity"
extern int timer_value;       // minutes
extern bool timer_active;

// States
extern bool switch_manual;    // manual relay toggle
extern bool relay_state;      // current relay state
extern int fan_speed;         // RPM

// Buttons / UI
extern int current_menu;      // 1..5
extern bool edit_mode;

// WiFi
extern const char* ssid;
extern const char* password;

extern unsigned long coolerTimerStart;
extern bool manual_override;


#endif
