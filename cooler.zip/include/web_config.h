#ifndef WEB_CONFIG_H
#define WEB_CONFIG_H
void startWebServer(const char* ssid, const char* password);
#endif
