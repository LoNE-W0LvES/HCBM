#ifndef FAN_SENSOR_H
#define FAN_SENSOR_H
void initFanSensor();
void updateFanSpeed();
#endif
