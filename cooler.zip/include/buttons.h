#ifndef BUTTONS_H
#define BUTTONS_H
void initButtons();
void handleButtons();
#endif
