#ifndef CONTROL_LOGIC_H
#define CONTROL_LOGIC_H
void initControl();
void updateControl();
#endif
