#ifndef SENSOR_READ_H
#define SENSOR_READ_H
void initSensors();
void readSensors();
#endif
