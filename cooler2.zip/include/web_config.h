#ifndef WEB_CONFIG_H
#define WEB_CONFIG_H
void startWebServer();
#endif
