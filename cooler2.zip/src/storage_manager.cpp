#include "storage_manager.h"
#include "variables.h"
#include <Preferences.h>

Preferences storage;

void initStorage() {
  storage.begin("cooler", false);
  Serial.println("[INIT] Storage manager initialized.");
}

void loadConfiguration() {
  upper_temp_threshold = storage.getFloat("upperTemp", 35.0);
  lower_temp_threshold = storage.getFloat("lowerTemp", 25.0);
  upper_hum_threshold = storage.getFloat("upperHum", 75.0);
  lower_hum_threshold = storage.getFloat("lowerHum", 45.0);
  mode = storage.getInt("mode", 1);
  String savedPriority = storage.getString("priority", "Temperature");
  priority = savedPriority;
  timer_value = storage.getInt("timerVal", 10);
  
  Serial.println("[STORAGE] Configuration loaded:");
  Serial.printf("  Temp: %.1f - %.1f°C\n", lower_temp_threshold, upper_temp_threshold);
  Serial.printf("  Hum: %.0f - %.0f%%\n", lower_hum_threshold, upper_hum_threshold);
  Serial.printf("  Mode: %d | Priority: %s | Timer: %d min\n", mode, priority.c_str(), timer_value);
}

void saveConfiguration() {
  storage.putFloat("upperTemp", upper_temp_threshold);
  storage.putFloat("lowerTemp", lower_temp_threshold);
  storage.putFloat("upperHum", upper_hum_threshold);
  storage.putFloat("lowerHum", lower_hum_threshold);
  storage.putInt("mode", mode);
  storage.putString("priority", priority);
  storage.putInt("timerVal", timer_value);
  Serial.println("[STORAGE] Configuration saved.");
}

void saveLanguage(const char* lang) {
  storage.putString("lang", lang);
  Serial.printf("[STORAGE] Language saved: %s\n", lang);
}

String getLanguage() {
  return storage.getString("lang", "en");
}