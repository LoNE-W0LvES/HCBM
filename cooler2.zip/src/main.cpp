#include <Arduino.h>
#include "sensor_read.h"
#include "control_logic.h"
#include "web_config.h"
#include "display.h"
#include "buttons.h"
#include "fan_sensor.h"
#include "variables.h"
#include "storage_manager.h"
#include "wifi_manager.h"

bool manual_override = false;

float internal_temp = 0, internal_hum = 0, ambient_temp = 0, ambient_hum = 0;
float upper_temp_threshold = 35, lower_temp_threshold = 25;
float upper_hum_threshold = 75, lower_hum_threshold = 45;
float lower_temp = 25, lower_hum = 45;  // Actual lower limits
int mode = 1;
String priority = "Temperature";
int timer_value = 10;
bool timer_active = false;
bool switch_manual = false;
bool relay_state = false;
int fan_speed = 0;
int current_menu = 1;
bool edit_mode = false;

unsigned long lastLog = 0;

void setup() {
  Serial.begin(115200);
  delay(500);
  
  Serial.println("\n╔════════════════════════════════╗");
  Serial.println("║  Smart Cooler v2.1             ║");
  Serial.println("╚════════════════════════════════╝\n");
  
  initStorage();
  loadConfiguration();
  
  initSensors();
  initControl();
  initDisplay();
  initButtons();
  initFanSensor();
  
  initWiFiManager();
  
  String ssid, password;
  bool hasCredentials = loadWiFiCredentials(ssid, password);
  
  if (hasCredentials) {
    Serial.println("[WIFI] Connecting...");
    if (!startWiFiClient()) {
      Serial.println("[WIFI] Failed. Starting AP mode...");
      startWiFiAP();
    }
  } else {
    Serial.println("[WIFI] No credentials. Starting AP mode...");
    startWiFiAP();
  }
  
  startWebServer();
  showRealtimeData();
  
  Serial.println("\n[BOOT] System ready!");
  Serial.println("════════════════════════════════\n");
}

void loop() {
  long currentMillis = millis();
  handleWiFiConnection();
  
  readSensors();
  
  // Calculate actual lower limits based on ambient
  lower_temp = (lower_temp_threshold < ambient_temp) ? ambient_temp : lower_temp_threshold;
  lower_hum = (lower_hum_threshold < ambient_hum) ? ambient_hum : lower_hum_threshold;
  
  updateFanSpeed();
  handleButtons();
  updateControl();
  updateDisplayIfNeeded();

  // if (millis() - lastLog >= 1000) {
  //   lastLog = millis();
  //   Serial.printf("[DATA] A:%.1f/%.0f%% I:%.1f/%.0f%% WiFi:%s\n",
  //                 ambient_temp, ambient_hum, internal_temp, internal_hum, 
  //                 getWiFiStatus().c_str());
  //   Serial.printf("[MODE] %s | Relay:%s | Fan:%d\n",
  //                 mode==1?"Auto":mode==2?"Manual":"Timer",
  //                 relay_state?"ON":"OFF", fan_speed);
  // }

  // delay(100);
  // Serial.print("Loop Time: ");
  // Serial.println(millis() - currentMillis);
}