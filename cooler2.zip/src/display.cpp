#include "display.h"
#include "variables.h"
#include "wifi_manager.h"
#include <Adafruit_SSD1306.h>
#include <Wire.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
#define I2C_SCL 9
#define I2C_SDA 8

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

static unsigned long lastUpdate = 0;
static bool showWiFiInfo = false;
static unsigned long wifiInfoTimer = 0;
extern unsigned long coolerTimerStart;

void initDisplay() {
  Wire.begin(I2C_SDA, I2C_SCL);
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("[ERR] OLED not found!");
    return;
  }

  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);
  display.setCursor(10, 0);
  display.println("OLED READY");
  display.display();

  Serial.println("[INIT] OLED initialized.");
}

void showWiFiInfoScreen() {
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);
  
  display.setCursor(0, 0);
  display.println("WiFi Information");
  display.println("----------------");
  
  if (getWiFiMode() == WIFI_AP_MODE) {
    display.println("Mode: Hotspot");
    display.println("SSID: SmartCooler");
    display.println("Pass: 12345678");
  } else {
    display.println("Mode: Connected");
    display.println("SSID: Connected");
  }
  
  display.print("IP: ");
  display.println(getIPAddress());
  
  display.display();
}

void showRealtimeData() {
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);

  // --- TOP LINE: depends on mode ---
  if (mode == 1) {  // Auto
    display.setCursor(0, 0);
    display.printf("T:%.1f-%.1fC H:%.0f-%.0f%%",
                   lower_temp_threshold, upper_temp_threshold,
                   lower_hum_threshold, upper_hum_threshold);
  }
  else if (mode == 3) {  // Timer mode
    unsigned long elapsedSec = (millis() - coolerTimerStart) / 1000UL;
    unsigned long totalSec = timer_value * 60UL;
    unsigned long remainingSec = (elapsedSec < totalSec) ? (totalSec - elapsedSec) : 0;
    
    int hh = remainingSec / 3600;
    int mm = (remainingSec % 3600) / 60;
    int ss = remainingSec % 60;
    
    display.setCursor(0, 0);
    display.printf("Rem: %02d:%02d:%02d", hh, mm, ss);
  }
  else {
    // Manual: show mode info
    display.setCursor(0, 0);
    display.print("Manual Control");
  }

  // --- Mode & Priority ---
  display.setCursor(0, 12);
  if (mode == 3) {
    display.printf("Mode:TMR  %s\n", relay_state ? "ON " : "OFF");
  } else if (mode == 1) {
    display.printf("Mode:AUT(%s)\n",
                   priority == "Temperature" ? "TMP" :
                   priority == "Humidity" ? "HUM" : "BTH");
  } else {
    display.printf("Mode:MAN  %s\n", relay_state ? "ON " : "OFF");
  }

  // --- Relay & Fan ---
  display.setCursor(0, 22);
  display.printf("RLY:%s  FAN:%d", relay_state ? "ON " : "OFF", fan_speed);

  // --- Internal conditions ---
  display.setCursor(0, 34);
  display.printf("Int T:%.1fC H:%.0f%%", internal_temp, internal_hum);

  // --- Ambient conditions ---
  display.setCursor(0, 46);
  display.printf("Amb T:%.1fC H:%.0f%%", ambient_temp, ambient_hum);

  // --- Bottom indicator - ONLY show in Manual mode ---
  if (mode == 2) {
    display.setCursor(0, 56);
    display.print("[MANUAL]");
  }

  display.display();
}

void showEditScreen(const String& label, float value) {
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);

  // Header
  display.setTextSize(1);
  display.setCursor(25, 0);
  display.println("EDIT MODE");

  // Label
  display.setTextSize(1);
  display.setCursor(0, 20);
  display.printf("%s:", label.c_str());

  // Large Value
  display.setTextSize(2);
  display.setCursor(10, 38);
  display.printf("%.1f", value);
  
  // Instructions
  display.setTextSize(1);
  display.setCursor(0, 56);
  display.print("Up/Dn +/- MID=OK");
  
  display.display();
}

void updateDisplayIfNeeded() {
  // Check if WiFi info should be shown
  if (showWiFiInfo) {
    if (millis() - wifiInfoTimer > 5000) {  // Show for 5 seconds
      showWiFiInfo = false;
      showRealtimeData();
    } else {
      showWiFiInfoScreen();
      return;
    }
  }
  
  if (millis() - lastUpdate > 1500 && !edit_mode) {
    showRealtimeData();
    lastUpdate = millis();
  }
}

void toggleWiFiInfo() {
  showWiFiInfo = !showWiFiInfo;
  wifiInfoTimer = millis();
  if (showWiFiInfo) {
    showWiFiInfoScreen();
  } else {
    showRealtimeData();
  }
}