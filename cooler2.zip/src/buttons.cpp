#include "buttons.h"
#include "variables.h"
#include "display.h"
#include "storage_manager.h"
#include "wifi_manager.h"

#define BTN_TOP     46
#define BTN_MID     18
#define BTN_BOTTOM  17
#define BTN_LEFT    16
#define BTN_RIGHT   15
#define HOLD_TIME_MS 10000

static unsigned long lastPress = 0;
static unsigned long btnTopPressStart = 0;
static bool btnTopHeld = false;
const unsigned long debounceMs = 180;
int currentParam = 0;

static inline bool pressed(int pin) {
  if (digitalRead(pin) == LOW && millis() - lastPress > debounceMs) {
    lastPress = millis();
    return true;
  }
  return false;
}

void initButtons() {
  pinMode(BTN_TOP, INPUT_PULLUP);
  pinMode(BTN_MID, INPUT_PULLUP);
  pinMode(BTN_BOTTOM, INPUT_PULLUP);
  pinMode(BTN_LEFT, INPUT_PULLUP);
  pinMode(BTN_RIGHT, INPUT_PULLUP);
  Serial.println("[INIT] Buttons initialized.");
}

void handleButtons() {
  // WiFi reset: hold BTN_TOP for 10 seconds
  if (digitalRead(BTN_TOP) == LOW) {
    if (btnTopPressStart == 0) {
      btnTopPressStart = millis();
    } else if (!btnTopHeld && millis() - btnTopPressStart >= HOLD_TIME_MS) {
      btnTopHeld = true;
      Serial.println("\n[BTN] WiFi Reset!");
      clearWiFiCredentials();
      delay(1000);
      ESP.restart();
    }
  } else {
    btnTopPressStart = 0;
    btnTopHeld = false;
  }

  if (!edit_mode) {
    if (pressed(BTN_TOP)) {
      toggleWiFiInfo();
      Serial.println("[BTN] WiFi info toggle");
    }

    if (pressed(BTN_LEFT)) {
      if (priority == "Temperature") priority = "Humidity";
      else if (priority == "Humidity") priority = "None";
      else priority = "Temperature";
      saveConfiguration();
      Serial.printf("[BTN] Priority -> %s\n", priority.c_str());
    }

    if (pressed(BTN_RIGHT)) {
      mode++;
      if (mode > 3) mode = 1;
      saveConfiguration();
      Serial.printf("[BTN] Mode -> %d\n", mode);
    }

    if (pressed(BTN_BOTTOM)) {
      // Set momentary pulse
      switch_manual = true;
      Serial.println("[BTN] Button pressed");
    }

    if (pressed(BTN_MID)) {
      edit_mode = true;
      currentParam = 0;
      Serial.println("[BTN] Edit mode");
      showEditScreen("Upper Temp", upper_temp_threshold);
    }
  }
  else {
    if (pressed(BTN_MID)) {
      edit_mode = false;
      saveConfiguration();
      Serial.println("[BTN] Exit edit");
      showRealtimeData();
      return;
    }

    if (pressed(BTN_TOP)) {
      currentParam--;
      if (currentParam < 0) currentParam = 4;
    }

    if (pressed(BTN_BOTTOM)) {
      currentParam++;
      if (currentParam > 4) currentParam = 0;
    }

    if (pressed(BTN_LEFT)) {
      switch (currentParam) {
        case 0: upper_temp_threshold -= 0.5; break;
        case 1: lower_temp_threshold -= 0.5; break;
        case 2: upper_hum_threshold -= 1; break;
        case 3: lower_hum_threshold -= 1; break;
        case 4: timer_value = max(1, timer_value - 1); break;
      }
    }

    if (pressed(BTN_RIGHT)) {
      switch (currentParam) {
        case 0: upper_temp_threshold += 0.5; break;
        case 1: lower_temp_threshold += 0.5; break;
        case 2: upper_hum_threshold += 1; break;
        case 3: lower_hum_threshold += 1; break;
        case 4: timer_value += 1; break;
      }
    }

    switch (currentParam) {
      case 0: showEditScreen("Upper Temp", upper_temp_threshold); break;
      case 1: showEditScreen("Lower Temp", lower_temp_threshold); break;
      case 2: showEditScreen("Upper Hum", upper_hum_threshold); break;
      case 3: showEditScreen("Lower Hum", lower_hum_threshold); break;
      case 4: showEditScreen("Timer (min)", timer_value); break;
    }
  }
}