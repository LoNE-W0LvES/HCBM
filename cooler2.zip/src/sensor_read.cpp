#include "sensor_read.h"
#include "variables.h"
#include <DHT.h>

// Pin map (user-confirmed)
#define DHTPIN_AMBIENT 13
#define DHTPIN_INTERNAL 10
#define DHTTYPE DHT22

DHT dhtAmbient(DHTPIN_AMBIENT, DHTTYPE);
DHT dhtInternal(DHTPIN_INTERNAL, DHTTYPE);

void initSensors() {
  dhtAmbient.begin();
  dhtInternal.begin();
  Serial.println("[INIT] DHT sensors initialized.");
}

void readSensors() {
  float at = dhtAmbient.readTemperature();
  float ah = dhtAmbient.readHumidity();
  float it = dhtInternal.readTemperature();
  float ih = dhtInternal.readHumidity();

  if (!isnan(at)) ambient_temp = at;
  if (!isnan(ah)) ambient_hum  = ah;
  if (!isnan(it)) internal_temp = it;
  if (!isnan(ih)) internal_hum  = ih;
}
