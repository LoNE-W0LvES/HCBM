#include "control_logic.h"
#include "variables.h"

#define RELAY_PIN 11

unsigned long coolerTimerStart = 0;
static bool timerState = false;

void initControl() {
  pinMode(RELAY_PIN, OUTPUT);
  digitalWrite(RELAY_PIN, LOW);
  relay_state = false;
  Serial.println("[INIT] Cooler control initialized.");
}

void updateControl() {
  bool relay_on = relay_state;

  // ===================================================
  // 🔘 Detect physical button press
  // ===================================================
  if (switch_manual) {
    switch_manual = false;  // Clear the flag immediately
    
    // In Auto mode: Check if allowed to turn ON
    if (mode == 1) {
      bool canTurnOn = false;
      
      if (priority == "Temperature") {
        canTurnOn = (internal_temp >= lower_temp);
      } else if (priority == "Humidity") {
        canTurnOn = (internal_hum >= lower_hum);
      } else { // Both
        canTurnOn = (internal_temp >= lower_temp) || 
                    (internal_hum >= lower_hum);
      }
      
      if (canTurnOn || !relay_state) {
        relay_state = !relay_state;
        digitalWrite(RELAY_PIN, relay_state ? HIGH : LOW);
        Serial.printf("[BUTTON] Relay -> %s\n", relay_state ? "ON" : "OFF");
      } else {
        Serial.println("[BUTTON] Blocked - below lower threshold");
      }
    }
    // Manual and Timer modes: always allow toggle
    else {
      relay_state = !relay_state;
      digitalWrite(RELAY_PIN, relay_state ? HIGH : LOW);
      Serial.printf("[BUTTON] Relay -> %s\n", relay_state ? "ON" : "OFF");
      
      if (mode == 3) {
        timerState = relay_state;
        coolerTimerStart = millis();
        Serial.println("[TIMER] Reset");
      }
    }
  }

  // ===================================================
  // 🧠 Mode-specific control logic
  // ===================================================

  // AUTO MODE – hysteresis control
  if (mode == 1) {
    if (priority == "Temperature") {
      if (relay_state) {
        relay_on = (internal_temp > lower_temp);
      } else {
        relay_on = (internal_temp > upper_temp_threshold);
      }
    } 
    else if (priority == "Humidity") {
      if (relay_state) {
        relay_on = (internal_hum > lower_hum);
      } else {
        relay_on = (internal_hum > upper_hum_threshold);
      }
    } 
    else { // Both
      if (relay_state) {
        relay_on = (internal_temp > lower_temp) || 
                   (internal_hum > lower_hum);
      } else {
        relay_on = (internal_temp > upper_temp_threshold) || 
                   (internal_hum > upper_hum_threshold);
      }
    }
  }

  // MANUAL MODE – user control
  else if (mode == 2) {
    relay_on = relay_state;
  }

  // TIMER MODE – scheduled operation
  else if (mode == 3) {
    unsigned long elapsedMin = (millis() - coolerTimerStart) / 60000UL;

    if (elapsedMin >= (unsigned long)timer_value) {
      coolerTimerStart = millis();
      timerState = !timerState;
      Serial.printf("[TIMER] Auto flip -> %s\n", timerState ? "ON" : "OFF");
    }

    relay_on = timerState;
  }

  // ===================================================
  // ⚡ Apply Relay Output
  // ===================================================
  if (relay_on != relay_state) {
    relay_state = relay_on;
    digitalWrite(RELAY_PIN, relay_state ? HIGH : LOW);
    Serial.printf("[COOLER] Relay %s\n", relay_state ? "ON" : "OFF");
  }
}