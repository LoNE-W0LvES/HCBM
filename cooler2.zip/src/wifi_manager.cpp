#include "wifi_manager.h"
#include <WiFi.h>
#include <Preferences.h>

// Configuration
#define AP_SSID "SmartCooler_Setup"
#define AP_PASSWORD "12345678"
#define WIFI_TIMEOUT_MS 10000
#define WIFI_RETRY_INTERVAL_MS 30000

// State variables
static WiFiMode currentMode = WIFI_CLIENT_MODE;
static unsigned long lastConnectionAttempt = 0;
static bool connectionInProgress = false;
static String savedSSID = "";
static String savedPassword = "";
static Preferences wifiPrefs;

void initWiFiManager() {
  wifiPrefs.begin("wificfg", false);
  WiFi.mode(WIFI_OFF);
  delay(100);
  Serial.println("[WIFI] WiFi Manager initialized.");
}

bool loadWiFiCredentials(String &ssid, String &password) {
  ssid = wifiPrefs.getString("ssid", "Wokwi-GUEST");
  password = wifiPrefs.getString("password", "");
  
  if (ssid.length() > 0) {
    savedSSID = ssid;
    savedPassword = password;
    Serial.printf("[WIFI] Loaded credentials: SSID='%s'\n", ssid.c_str());
    return true;
  }
  
  Serial.println("[WIFI] No saved credentials found.");
  return false;
}

void saveWiFiCredentials(const char* ssid, const char* password) {
  wifiPrefs.putString("ssid", ssid);
  wifiPrefs.putString("password", password);
  savedSSID = String(ssid);
  savedPassword = String(password);
  Serial.printf("[WIFI] Credentials saved: SSID='%s'\n", ssid);
}

void clearWiFiCredentials() {
  wifiPrefs.remove("ssid");
  wifiPrefs.remove("password");
  savedSSID = "";
  savedPassword = "";
  Serial.println("[WIFI] Credentials cleared.");
}

bool startWiFiClient() {
  if (savedSSID.length() == 0) {
    Serial.println("[WIFI] No credentials available for client mode.");
    return false;
  }
  
  WiFi.mode(WIFI_STA);
  WiFi.begin(savedSSID.c_str(), savedPassword.c_str());
  
  Serial.printf("[WIFI] Connecting to '%s'", savedSSID.c_str());
  
  unsigned long startAttempt = millis();
  connectionInProgress = true;
  
  while (WiFi.status() != WL_CONNECTED && 
         millis() - startAttempt < WIFI_TIMEOUT_MS) {
    delay(100);
    Serial.print(".");
  }
  
  connectionInProgress = false;
  
  if (WiFi.status() == WL_CONNECTED) {
    currentMode = WIFI_CLIENT_MODE;
    Serial.println("\n[WIFI] ✓ Connected!");
    Serial.printf("[WIFI] IP Address: %s\n", WiFi.localIP().toString().c_str());
    Serial.printf("[WIFI] Signal: %d dBm\n", WiFi.RSSI());
    lastConnectionAttempt = millis();
    return true;
  } else {
    Serial.println("\n[WIFI] ✗ Connection failed.");
    lastConnectionAttempt = millis();
    return false;
  }
}

void startWiFiAP() {
  WiFi.mode(WIFI_AP);
  WiFi.softAP(AP_SSID, AP_PASSWORD);
  
  currentMode = WIFI_AP_MODE;
  
  Serial.println("\n[WIFI] ━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
  Serial.println("[WIFI] 📶 Access Point Mode Enabled");
  Serial.println("[WIFI] ━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
  Serial.printf("[WIFI] SSID: %s\n", AP_SSID);
  Serial.printf("[WIFI] Password: %s\n", AP_PASSWORD);
  Serial.printf("[WIFI] IP Address: %s\n", WiFi.softAPIP().toString().c_str());
  Serial.println("[WIFI] ━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
  Serial.println("[WIFI] Connect to setup WiFi");
  Serial.println("[WIFI] ━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
}

void handleWiFiConnection() {
  if (currentMode != WIFI_CLIENT_MODE) return;
  if (WiFi.status() == WL_CONNECTED) return;
  if (connectionInProgress) return;
  
  if (millis() - lastConnectionAttempt < WIFI_RETRY_INTERVAL_MS) {
    return;
  }
  
  Serial.println("[WIFI] Connection lost. Attempting to reconnect...");
  startWiFiClient();
}

WiFiMode getWiFiMode() {
  return currentMode;
}

String getWiFiStatus() {
  if (currentMode == WIFI_AP_MODE) {
    return "AP Mode";
  }
  
  switch (WiFi.status()) {
    case WL_CONNECTED:
      return "Connected";
    case WL_NO_SSID_AVAIL:
      return "SSID Not Found";
    case WL_CONNECT_FAILED:
      return "Connection Failed";
    case WL_CONNECTION_LOST:
      return "Connection Lost";
    case WL_DISCONNECTED:
      return "Disconnected";
    default:
      return "Unknown";
  }
}

String getIPAddress() {
  if (currentMode == WIFI_AP_MODE) {
    return WiFi.softAPIP().toString();
  }
  return WiFi.localIP().toString();
}

bool isWiFiConnected() {
  if (currentMode == WIFI_AP_MODE) return true;
  return WiFi.status() == WL_CONNECTED;
}

String scanWiFiNetworks() {
  Serial.println("[WIFI] Scanning networks...");
  int n = WiFi.scanNetworks();
  
  String json = "[";
  
  if (n == 0) {
    json += "]";
    Serial.println("[WIFI] No networks found.");
    return json;
  }
  
  Serial.printf("[WIFI] Found %d networks\n", n);
  
  for (int i = 0; i < n; i++) {
    if (i > 0) json += ",";
    
    json += "{";
    json += "\"ssid\":\"" + WiFi.SSID(i) + "\",";
    json += "\"rssi\":" + String(WiFi.RSSI(i)) + ",";
    json += "\"encryption\":" + String(WiFi.encryptionType(i));
    json += "}";
  }
  
  json += "]";
  WiFi.scanDelete();
  
  return json;
}